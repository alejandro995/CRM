@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:bbva:ccol:account:facade:v02:dto")
package com.bbva.ccol.account.facade.v01.dto;
