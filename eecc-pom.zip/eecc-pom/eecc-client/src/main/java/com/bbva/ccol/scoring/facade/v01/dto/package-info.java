@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:bbva:ccol:scoring:facade:v01:dto")
package com.bbva.ccol.scoring.facade.v01.dto;
