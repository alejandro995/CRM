@javax.xml.bind.annotation.XmlSchema(namespace = "bbva:czic:customers:facade:v02:dto")
package com.bbva.ccol.customers.facade.v02.dto;
