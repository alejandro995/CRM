@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:bbva:czic:dto:net")
package com.bbva.ccol.loans.facade.v02.dto;
