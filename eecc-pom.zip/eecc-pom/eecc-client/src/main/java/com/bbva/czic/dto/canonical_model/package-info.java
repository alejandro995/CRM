@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:bbva:czic:dto:canonical_model")
package com.bbva.czic.dto.canonical_model;
