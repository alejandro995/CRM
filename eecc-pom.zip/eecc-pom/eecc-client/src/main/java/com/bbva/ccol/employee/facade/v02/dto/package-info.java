@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:bbva:ccol:employees:facade:v00:dto")
package com.bbva.ccol.employee.facade.v02.dto;
